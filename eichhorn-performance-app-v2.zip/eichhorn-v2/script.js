/* =========================================================
   EICHHORN PERFORMANCE – script.js
   - visuelle Terminblöcke im Kalender (Dauer sichtbar)
   - mehrere Trainer mit eigenem Login
   - Verlaufsanalyse pro Kunde und Übung
   ========================================================= */

/* --------- HILFSFUNKTIONEN --------- */
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, ch =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}
function pad(n) { return String(n).padStart(2, "0"); }
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/* --------- VIEW HANDLING --------- */
const views = {
  login:    document.getElementById("login-view"),
  dash:     document.getElementById("dashboard-view"),
  cust:     document.getElementById("customers-view"),
  cal:      document.getElementById("calendar-view"),
  sess:     document.getElementById("session-view"),
  progress: document.getElementById("progress-view"),
  trainers: document.getElementById("trainers-view")
};
const header = document.getElementById("main-header");

function show(v) {
  Object.values(views).forEach(x => x.classList.add("hidden"));
  v.classList.remove("hidden");
  if (v === views.login) header.classList.add("hidden");
  else header.classList.remove("hidden");
}
show(views.login);

document.getElementById("logo-dashboard").onclick = () => {
  if (state.currentTrainer) show(views.dash);
};

/* --------- STORAGE --------- */
const KEY = "EP_DATA_V2";
const OLD_KEY = "EP_DATA_V1";
const DEFAULT_TRAINERS = [
  { id: 1, name: "Admin",   username: "admin",   password: "admin123", isAdmin: true  },
  { id: 2, name: "Trainer", username: "trainer", password: "1234",     isAdmin: false }
];

function loadData() {
  let data = null;
  try { data = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
  if (!data) {
    // Migration: bestehende Daten der alten Version übernehmen
    try { data = JSON.parse(localStorage.getItem(OLD_KEY)); } catch (e) {}
  }
  if (!data) data = {};
  data.customers    = data.customers    || [];
  data.appointments = data.appointments || [];
  if (!data.trainers || !data.trainers.length) data.trainers = DEFAULT_TRAINERS;
  data.customers.forEach(c => { c.sessions = c.sessions || []; });
  return data;
}

const state = {
  data: loadData(),
  currentTrainer: null,
  selectedCustomer: null,
  directMode: false,
  newSessionCustomer: null,
  calYear: new Date().getFullYear(),
  calMonth: new Date().getMonth(),
  calSelected: null,
  editing: null
};

function save() {
  localStorage.setItem(KEY, JSON.stringify(state.data));
  updateBirthday();
}
save();

/* --------- LOGIN / LOGOUT --------- */
function doLogin() {
  const u = document.getElementById("login-username").value.trim();
  const p = document.getElementById("login-password").value;
  const err = document.getElementById("login-error");
  const trainer = state.data.trainers.find(t => t.username === u && t.password === p);
  if (trainer) {
    state.currentTrainer = trainer;
    err.classList.add("hidden");
    document.getElementById("header-trainer-name").textContent = trainer.name;
    document.querySelectorAll(".admin-only").forEach(el => {
      el.classList.toggle("hidden", !trainer.isAdmin);
    });
    show(views.dash);
    updateBirthday();
  } else {
    err.textContent = "Benutzername oder Passwort ist falsch.";
    err.classList.remove("hidden");
  }
}
document.getElementById("login-btn").onclick = doLogin;
document.getElementById("login-password").addEventListener("keydown", e => {
  if (e.key === "Enter") doLogin();
});

document.getElementById("logout-btn").onclick = () => {
  state.currentTrainer = null;
  document.getElementById("login-username").value = "";
  document.getElementById("login-password").value = "";
  document.getElementById("header-trainer-name").textContent = "";
  show(views.login);
};

/* --------- NAVIGATION --------- */
document.querySelectorAll(".back-btn").forEach(btn => {
  btn.onclick = () => {
    state.directMode = false;
    show(views.dash);
  };
});

document.getElementById("btn-customers").onclick = () => {
  state.directMode = false;
  document.getElementById("customers-hint").classList.add("hidden");
  show(views.cust);
  renderCustomers();
  renderCustomerDetail();
};
document.getElementById("btn-calendar").onclick = () => {
  show(views.cal);
  renderCalendar();
  fillApptModalSelect();
  renderDayAppointments();
};
document.getElementById("btn-progress").onclick = () => {
  show(views.progress);
  fillProgressCustomerSelect();
  resetProgressView();
};
document.getElementById("btn-trainers").onclick = () => {
  show(views.trainers);
  document.getElementById("trainer-form-wrapper").classList.add("hidden");
  renderTrainers();
};

/* --------- DASHBOARD: NEUE EINHEIT --------- */
const sessionCustomerBlock = document.getElementById("session-customer-block");
const sessionCustomerDropdown = document.getElementById("session-customer-dropdown");
const sessionForm = document.getElementById("session-form");

document.getElementById("btn-new-session").onclick = () => {
  state.directMode = true;
  show(views.sess);
  sessionCustomerBlock.classList.remove("hidden");
  sessionCustomerDropdown.innerHTML = "";
  state.data.customers
    .slice()
    .sort((a, b) => (a.last || "").localeCompare(b.last || ""))
    .forEach(c => {
      const opt = document.createElement("option");
      opt.value = c.id;
      opt.textContent = `${c.first} ${c.last}`;
      sessionCustomerDropdown.appendChild(opt);
    });
  sessionForm.reset();
  document.getElementById("session-date").value = todayStr();
  document.getElementById("session-view-title").textContent = "Neue Trainingseinheit";
};

/* --------- KUNDENLISTE / DETAIL --------- */
const custList = document.getElementById("customer-list");
const custSearch = document.getElementById("customer-search");
custSearch.oninput = renderCustomers;

function renderCustomers() {
  const s = custSearch.value.toLowerCase();
  custList.innerHTML = "";
  state.data.customers
    .slice()
    .sort((a, b) => (a.last || "").localeCompare(b.last || ""))
    .forEach(c => {
      const name = `${c.first} ${c.last}`.trim();
      if (s && !name.toLowerCase().includes(s)) return;
      const li = document.createElement("li");
      li.textContent = name || "(ohne Namen)";
      if (c.id === Number(state.selectedCustomer)) li.classList.add("active");
      li.onclick = () => {
        state.selectedCustomer = c.id;
        if (state.directMode) return openNewSession(c);
        renderCustomers();
        renderCustomerDetail();
      };
      custList.appendChild(li);
    });
}

const custDetail = document.getElementById("customer-detail");
const custEmpty = document.getElementById("customer-empty");
const custFormWrap = document.getElementById("customer-form-wrapper");

let stammdatenOffen = false;
document.getElementById("detail-name").onclick = e => {
  if (e.target.closest(".icon-btn")) return;
  stammdatenOffen = !stammdatenOffen;
  document.getElementById("customer-stammdaten").classList.toggle("hidden", !stammdatenOffen);
};

function renderCustomerDetail() {
  const c = state.data.customers.find(x => x.id === Number(state.selectedCustomer));
  if (!c) {
    custDetail.classList.add("hidden");
    custFormWrap.classList.add("hidden");
    custEmpty.classList.remove("hidden");
    return;
  }
  custEmpty.classList.add("hidden");
  custFormWrap.classList.add("hidden");
  custDetail.classList.remove("hidden");
  document.getElementById("customer-name-text").textContent = `${c.first} ${c.last}`;
  document.getElementById("detail-dob").textContent = c.dob || "-";
  const addrParts = [c.street, [c.zip, c.city].filter(Boolean).join(" ")].filter(Boolean);
  document.getElementById("detail-address").textContent = addrParts.length ? addrParts.join(", ") : "-";
  document.getElementById("detail-phone").textContent = c.phone || "-";
  document.getElementById("detail-email").textContent = c.email || "-";
  document.getElementById("history-block").style.display = state.directMode ? "none" : "block";
  document.getElementById("customer-stammdaten").classList.add("hidden");
  stammdatenOffen = false;
  renderSessions(c);
}

const sessionList = document.getElementById("session-list");
function renderSessions(c) {
  sessionList.innerHTML = "";
  (c.sessions || [])
    .slice()
    .sort((a, b) => (a.date || "").localeCompare(b.date || ""))
    .forEach((s, i) => {
      const li = document.createElement("li");
      li.className = "session-card";
      li.innerHTML = `
        <div class="session-dot">${i + 1}</div>
        <div>
          <div class="session-card-title">${s.date ? s.date.split("-").reverse().join(".") : "–"}</div>
          <div class="session-card-plan">${esc(s.plan)}</div>
        </div>`;
      li.onclick = () => openEditSession(c, s);
      sessionList.appendChild(li);
    });
}

/* --------- KUNDEN ANLEGEN / BEARBEITEN / LÖSCHEN --------- */
document.getElementById("new-customer-btn").onclick = () => {
  custDetail.classList.add("hidden");
  custEmpty.classList.add("hidden");
  custFormWrap.classList.remove("hidden");
  document.getElementById("customer-form-title").textContent = "Neue KundIn";
  document.getElementById("customer-form").reset();
  document.getElementById("cust-id").value = "";
};
document.getElementById("cancel-customer-form").onclick = () => {
  custFormWrap.classList.add("hidden");
  renderCustomerDetail();
};
document.getElementById("edit-customer-btn").onclick = () => {
  const c = state.data.customers.find(x => x.id === Number(state.selectedCustomer));
  if (!c) return;
  custDetail.classList.add("hidden");
  custEmpty.classList.add("hidden");
  custFormWrap.classList.remove("hidden");
  document.getElementById("customer-form-title").textContent = "KundIn bearbeiten";
  document.getElementById("cust-id").value = c.id;
  document.getElementById("cust-firstname").value = c.first;
  document.getElementById("cust-lastname").value = c.last;
  document.getElementById("cust-dob").value = c.dob || "";
  document.getElementById("cust-street").value = c.street || "";
  document.getElementById("cust-zip").value = c.zip || "";
  document.getElementById("cust-city").value = c.city || "";
  document.getElementById("cust-phone").value = c.phone || "";
  document.getElementById("cust-email").value = c.email || "";
};
document.getElementById("delete-customer-btn").onclick = () => {
  const c = state.data.customers.find(x => x.id === Number(state.selectedCustomer));
  if (!c) return;
  if (confirm(`KundIn "${c.first} ${c.last}" wirklich löschen?`)) {
    state.data.customers = state.data.customers.filter(x => x.id !== c.id);
    state.data.appointments = state.data.appointments.filter(a => Number(a.customerId) !== c.id);
    state.selectedCustomer = null;
    save();
    renderCustomers();
    renderCustomerDetail();
  }
};
document.getElementById("customer-form").onsubmit = e => {
  e.preventDefault();
  const id = document.getElementById("cust-id").value;
  const data = {
    first:  document.getElementById("cust-firstname").value.trim(),
    last:   document.getElementById("cust-lastname").value.trim(),
    dob:    document.getElementById("cust-dob").value,
    street: document.getElementById("cust-street").value.trim(),
    zip:    document.getElementById("cust-zip").value.trim(),
    city:   document.getElementById("cust-city").value.trim(),
    phone:  document.getElementById("cust-phone").value.trim(),
    email:  document.getElementById("cust-email").value.trim()
  };
  if (!data.first && !data.last) {
    alert("Bitte mindestens Vor- oder Nachname eingeben.");
    return;
  }
  if (id) {
    const c = state.data.customers.find(x => x.id === Number(id));
    Object.assign(c, data);
    state.selectedCustomer = c.id;
  } else {
    const c = { id: Date.now(), ...data, sessions: [] };
    state.data.customers.push(c);
    state.selectedCustomer = c.id;
  }
  save();
  custFormWrap.classList.add("hidden");
  renderCustomers();
  renderCustomerDetail();
  fillApptModalSelect();
};

/* --------- NEUE EINHEIT AUS KUNDENPROFIL --------- */
function openNewSession(c) {
  state.newSessionCustomer = c.id;
  sessionForm.reset();
  document.getElementById("session-date").value = todayStr();
  document.getElementById("session-view-title").textContent =
    `Neue Trainingseinheit für ${c.first} ${c.last}`;
  sessionCustomerBlock.classList.add("hidden");
  show(views.sess);
}
document.getElementById("new-session-btn").onclick = () => {
  const c = state.data.customers.find(x => x.id === Number(state.selectedCustomer));
  if (c) openNewSession(c);
};
document.getElementById("btn-progress-customer").onclick = () => {
  const c = state.data.customers.find(x => x.id === Number(state.selectedCustomer));
  if (!c) return;
  show(views.progress);
  fillProgressCustomerSelect(c.id);
};

sessionForm.onsubmit = e => {
  e.preventDefault();
  const dateVal = document.getElementById("session-date").value;
  if (!dateVal) {
    alert("Bitte ein Datum für die Trainingseinheit angeben.");
    return;
  }
  let c = null;
  if (!sessionCustomerBlock.classList.contains("hidden")) {
    c = state.data.customers.find(x => x.id === Number(sessionCustomerDropdown.value));
    if (!c) { alert("Bitte einen Kunden auswählen!"); return; }
  } else {
    c = state.data.customers.find(x => x.id === state.newSessionCustomer);
    if (!c) return;
  }
  c.sessions.push({
    id: Date.now(),
    date: dateVal,
    notes: document.getElementById("session-notes").value.trim(),
    plan: document.getElementById("session-plan").value.trim()
  });
  state.selectedCustomer = c.id;
  save();
  state.directMode = false;
  sessionCustomerBlock.classList.add("hidden");
  show(views.cust);
  renderCustomers();
  renderCustomerDetail();
};

/* --------- SESSION MODAL (Bearbeiten) --------- */
const modal = document.getElementById("session-modal");
function openEditSession(c, s) {
  state.editing = { cid: c.id, sid: s.id };
  document.getElementById("edit-session-id").value = s.id;
  document.getElementById("edit-session-date").value = s.date;
  document.getElementById("edit-session-notes").value = s.notes || "";
  document.getElementById("edit-session-plan").value = s.plan || "";
  modal.classList.remove("hidden");
}
function closeModal() {
  modal.classList.add("hidden");
  state.editing = null;
}
document.getElementById("cancel-session-edit").onclick = closeModal;
modal.querySelector(".modal-backdrop").onclick = closeModal;
document.getElementById("session-edit-form").onsubmit = e => {
  e.preventDefault();
  const dateVal = document.getElementById("edit-session-date").value;
  if (!dateVal) { alert("Bitte ein Datum angeben."); return; }
  const { cid, sid } = state.editing;
  const c = state.data.customers.find(x => x.id === cid);
  const s = c.sessions.find(x => x.id === sid);
  s.date = dateVal;
  s.notes = document.getElementById("edit-session-notes").value.trim();
  s.plan = document.getElementById("edit-session-plan").value.trim();
  save();
  closeModal();
  renderCustomerDetail();
};
document.getElementById("delete-session-btn").onclick = () => {
  const { cid, sid } = state.editing;
  const c = state.data.customers.find(x => x.id === cid);
  c.sessions = c.sessions.filter(x => x.id !== sid);
  save();
  closeModal();
  renderCustomerDetail();
};

/* =========================================================
   KALENDER
   ========================================================= */
const calLabel = document.getElementById("cal-label");
const calDays = document.getElementById("cal-days");

function renderCalendar() {
  const m = state.calMonth;
  const y = state.calYear;
  const names = ["Jänner", "Februar", "März", "April", "Mai", "Juni",
                 "Juli", "August", "September", "Oktober", "November", "Dezember"];
  calLabel.textContent = `${names[m]} ${y}`;
  const first = new Date(y, m, 1);
  const start = (first.getDay() + 6) % 7;
  const days = new Date(y, m + 1, 0).getDate();
  calDays.innerHTML = "";
  for (let i = 0; i < start; i++) {
    const b = document.createElement("button");
    b.disabled = true;
    b.style.opacity = "0";
    calDays.appendChild(b);
  }
  const today = todayStr();
  for (let d = 1; d <= days; d++) {
    const b = document.createElement("button");
    const ds = `${y}-${pad(m + 1)}-${pad(d)}`;
    b.textContent = d;
    if (ds === today) b.classList.add("today");
    if (ds === state.calSelected) b.classList.add("selected");
    b.onclick = () => {
      state.calSelected = ds;
      renderCalendar();
      renderDayAppointments();
    };
    calDays.appendChild(b);
  }
}
document.getElementById("cal-prev").onclick = () => {
  if (state.calMonth === 0) { state.calMonth = 11; state.calYear--; }
  else state.calMonth--;
  renderCalendar();
  renderDayAppointments();
};
document.getElementById("cal-next").onclick = () => {
  if (state.calMonth === 11) { state.calMonth = 0; state.calYear++; }
  else state.calMonth++;
  renderCalendar();
  renderDayAppointments();
};

/* --------- TERMIN EINTRAGEN --------- */
const apptModal = document.getElementById("appt-modal");
const apptModalForm = document.getElementById("appt-modal-form");
const apptModalCustomer = document.getElementById("appt-modal-customer");
const apptModalStart = document.getElementById("appt-modal-start");
const apptModalEnd = document.getElementById("appt-modal-end");
const apptModalNote = document.getElementById("appt-modal-note");

function fillApptModalSelect() {
  apptModalCustomer.innerHTML = "";
  state.data.customers
    .slice()
    .sort((a, b) => (a.last || "").localeCompare(b.last || ""))
    .forEach(c => {
      const opt = document.createElement("option");
      opt.value = c.id;
      opt.textContent = `${c.first} ${c.last}`;
      apptModalCustomer.appendChild(opt);
    });
}
document.getElementById("add-appt-btn").onclick = () => {
  if (!state.calSelected) {
    alert("Bitte zuerst einen Tag im Kalender auswählen.");
    return;
  }
  if (!state.data.customers.length) {
    alert("Bitte zuerst eine KundIn anlegen.");
    return;
  }
  fillApptModalSelect();
  const h = new Date().getHours();
  apptModalStart.value = `${pad(h)}:00`;
  apptModalEnd.value = `${pad(Math.min(h + 1, 23))}:${h >= 23 ? "59" : "00"}`;
  apptModalNote.value = "";
  apptModal.classList.remove("hidden");
};
document.getElementById("appt-modal-cancel").onclick = () => apptModal.classList.add("hidden");
apptModal.querySelector(".modal-backdrop").onclick = () => apptModal.classList.add("hidden");
apptModalForm.onsubmit = e => {
  e.preventDefault();
  if (!state.calSelected) { alert("Bitte zuerst einen Tag auswählen."); return; }
  const cid = Number(apptModalCustomer.value);
  if (!cid) { alert("Bitte KundIn auswählen."); return; }
  const start = apptModalStart.value;
  const end = apptModalEnd.value;
  if (!start || !end || start >= end) {
    alert("Ungültige Zeitangabe – das Ende muss nach dem Beginn liegen.");
    return;
  }
  state.data.appointments.push({
    id: Date.now(),
    date: state.calSelected,
    customerId: cid,
    start,
    end,
    note: apptModalNote.value.trim()
  });
  save();
  apptModal.classList.add("hidden");
  renderDayAppointments();
};

/* --------- TERMIN BEARBEITEN --------- */
const apptEditModal = document.createElement("div");
apptEditModal.id = "appt-edit-modal";
apptEditModal.className = "hidden";
apptEditModal.innerHTML = `
  <div class="modal-backdrop"></div>
  <div class="modal-content">
    <h3>Termin bearbeiten</h3>
    <form id="appt-edit-form">
      <input id="edit-appt-id" type="hidden">
      <label>Kunde: <select id="edit-appt-customer"></select></label>
      <label>Von: <input id="edit-appt-start" type="time" required></label>
      <label>Bis: <input id="edit-appt-end" type="time" required></label>
      <label>Notiz: <textarea id="edit-appt-note" rows="2"></textarea></label>
      <div class="form-actions">
        <button type="submit" class="btn-primary">Speichern</button>
        <button type="button" id="delete-appt-btn" class="btn-danger">Löschen</button>
        <button type="button" id="cancel-appt-edit" class="btn-outline">Abbrechen</button>
      </div>
    </form>
  </div>`;
document.querySelector("main").appendChild(apptEditModal);

function openEditAppointment(appt) {
  document.getElementById("edit-appt-id").value = appt.id;
  document.getElementById("edit-appt-start").value = appt.start;
  document.getElementById("edit-appt-end").value = appt.end;
  document.getElementById("edit-appt-note").value = appt.note || "";
  const sel = document.getElementById("edit-appt-customer");
  sel.innerHTML = "";
  state.data.customers.forEach(c => {
    const o = document.createElement("option");
    o.value = c.id;
    o.textContent = `${c.first} ${c.last}`;
    if (c.id === Number(appt.customerId)) o.selected = true;
    sel.appendChild(o);
  });
  apptEditModal.classList.remove("hidden");
}
document.getElementById("cancel-appt-edit").onclick = () => apptEditModal.classList.add("hidden");
apptEditModal.querySelector(".modal-backdrop").onclick = () => apptEditModal.classList.add("hidden");
document.getElementById("appt-edit-form").onsubmit = e => {
  e.preventDefault();
  const id = Number(document.getElementById("edit-appt-id").value);
  const appt = state.data.appointments.find(a => a.id === id);
  if (!appt) return;
  const start = document.getElementById("edit-appt-start").value;
  const end = document.getElementById("edit-appt-end").value;
  if (start >= end) { alert("Endzeit muss nach Startzeit liegen."); return; }
  appt.start = start;
  appt.end = end;
  appt.customerId = Number(document.getElementById("edit-appt-customer").value);
  appt.note = document.getElementById("edit-appt-note").value.trim();
  save();
  apptEditModal.classList.add("hidden");
  renderDayAppointments();
};
document.getElementById("delete-appt-btn").onclick = () => {
  if (!confirm("Termin wirklich löschen?")) return;
  const id = Number(document.getElementById("edit-appt-id").value);
  state.data.appointments = state.data.appointments.filter(a => a.id !== id);
  save();
  apptEditModal.classList.add("hidden");
  renderDayAppointments();
};

/* --------- TAGESANSICHT: Termine über ihre volle Dauer ---------
   Eine Stunde = 60px. Ein Termin 15:00–16:00 füllt die ganze
   15-Uhr-Zeile, 15:30–17:00 reicht von der Mitte der 15-Uhr-Zeile
   bis ans Ende der 16-Uhr-Zeile.                                  */
const dayTitle = document.getElementById("day-title");
const dayAppointments = document.getElementById("day-appointments");

function renderDayAppointments() {
  dayAppointments.innerHTML = "";
  if (!state.calSelected) {
    dayTitle.textContent = "Tag auswählen";
    return;
  }
  dayTitle.textContent = `Termine am ${state.calSelected.split("-").reverse().join(".")}`;

  const appts = state.data.appointments
    .filter(a => a.date === state.calSelected)
    .sort((a, b) => a.start.localeCompare(b.start));

  // sichtbarer Bereich: mind. 07–20 Uhr, erweitert sich bei Bedarf
  let minHour = 7;
  let maxHour = 20;
  appts.forEach(a => {
    const sh = parseInt(a.start.split(":")[0], 10);
    const [eh, em] = a.end.split(":").map(Number);
    const lastHour = em === 0 ? eh - 1 : eh;
    if (sh < minHour) minHour = sh;
    if (lastHour > maxHour) maxHour = lastHour;
  });

  for (let hour = minHour; hour <= maxHour; hour++) {
    const row = document.createElement("div");
    row.className = "time-row";

    const lbl = document.createElement("div");
    lbl.className = "time-label";
    lbl.textContent = `${pad(hour)}:00`;

    const slot = document.createElement("div");
    slot.className = "time-slot";

    appts.forEach(a => {
      const [sh, sm] = a.start.split(":").map(Number);
      const [eh, em] = a.end.split(":").map(Number);
      const startMin = sh * 60 + sm;
      const endMin = eh * 60 + em;
      const hourStart = hour * 60;
      const hourEnd = hourStart + 60;

      if (endMin <= hourStart || startMin >= hourEnd) return;

      const segStart = Math.max(startMin, hourStart) - hourStart;
      const segEnd = Math.min(endMin, hourEnd) - hourStart;

      const block = document.createElement("div");
      block.className = "appt-block";
      block.style.top = segStart + "px";
      block.style.height = Math.max(segEnd - segStart, 18) + "px";

      const c = state.data.customers.find(x => x.id === Number(a.customerId));
      const label = `${a.start}–${a.end} ${c ? c.first + " " + c.last : ""}`.trim();
      if (startMin >= hourStart) {
        block.textContent = label;
      } else {
        block.textContent = "⋮";
      }
      block.title = a.note ? `${label}\n${a.note}` : label;
      block.onclick = ev => {
        ev.stopPropagation();
        openEditAppointment(a);
      };
      slot.appendChild(block);
    });

    row.appendChild(lbl);
    row.appendChild(slot);
    dayAppointments.appendChild(row);
  }
}

/* =========================================================
   VERLAUFSANALYSE
   Der Trainingsplan wird zeilenweise gelesen. Erkanntes Format:
     Bankdrücken: 3x10 @ 80kg
     Kniebeuge: 4x8 @ 100 kg
   ========================================================= */
const progCustSel = document.getElementById("progress-customer-select");
const progExSel = document.getElementById("progress-exercise-select");
const progContent = document.getElementById("progress-content");

function resetProgressView() {
  progExSel.innerHTML = '<option value="">-- Übung wählen --</option>';
  progContent.innerHTML = '<p style="color:#888;margin-top:16px;">Bitte Kunde und Übung auswählen.</p>';
}

function fillProgressCustomerSelect(preselect) {
  progCustSel.innerHTML = '<option value="">-- Kunde wählen --</option>';
  state.data.customers
    .slice()
    .sort((a, b) => (a.last || "").localeCompare(b.last || ""))
    .forEach(c => {
      const o = document.createElement("option");
      o.value = c.id;
      o.textContent = `${c.first} ${c.last}`;
      if (preselect && c.id === preselect) o.selected = true;
      progCustSel.appendChild(o);
    });
  if (preselect) buildProgressExerciseList(preselect);
  else resetProgressView();
}

progCustSel.onchange = () => {
  const cid = Number(progCustSel.value);
  if (cid) buildProgressExerciseList(cid);
  else resetProgressView();
};
progExSel.onchange = () => {
  const cid = Number(progCustSel.value);
  if (cid && progExSel.value) renderProgress(cid, progExSel.value);
};

function parseExerciseLine(line) {
  const m = line.match(/^([^:]+):\s*(\d+)\s*[xX×]\s*(\d+)\s*@?\s*(\d+(?:[.,]\d+)?)\s*(?:kg)?/i);
  if (!m) return null;
  return {
    name: m[1].trim(),
    sets: parseInt(m[2], 10),
    reps: parseInt(m[3], 10),
    weight: parseFloat(m[4].replace(",", "."))
  };
}

function getExercisesFromCustomer(cid) {
  const c = state.data.customers.find(x => x.id === cid);
  if (!c) return [];
  const map = {};
  (c.sessions || []).forEach(s => {
    (s.plan || "").split("\n").forEach(line => {
      const ex = parseExerciseLine(line.trim());
      if (ex) map[ex.name.toLowerCase()] = ex.name;
    });
  });
  return Object.values(map).sort((a, b) => a.localeCompare(b));
}

function buildProgressExerciseList(cid) {
  const list = getExercisesFromCustomer(cid);
  progExSel.innerHTML = '<option value="">-- Übung wählen --</option>';
  list.forEach(name => {
    const o = document.createElement("option");
    o.value = name;
    o.textContent = name;
    progExSel.appendChild(o);
  });
  progContent.innerHTML = list.length
    ? '<p style="color:#888;margin-top:16px;">Übung auswählen, um den Verlauf zu sehen.</p>'
    : '<p style="color:#888;margin-top:16px;">Noch keine auswertbaren Einheiten vorhanden.<br><small>Format im Trainingsplan, eine Übung pro Zeile: <strong>Bankdrücken: 3x10 @ 80kg</strong></small></p>';
}

function renderProgress(cid, exerciseName) {
  const c = state.data.customers.find(x => x.id === cid);
  if (!c) return;

  const points = [];
  (c.sessions || [])
    .slice()
    .sort((a, b) => (a.date || "").localeCompare(b.date || ""))
    .forEach(s => {
      (s.plan || "").split("\n").forEach(line => {
        const ex = parseExerciseLine(line.trim());
        if (ex && ex.name.toLowerCase() === exerciseName.toLowerCase()) {
          points.push({
            date: s.date,
            sets: ex.sets,
            reps: ex.reps,
            weight: ex.weight,
            volume: ex.sets * ex.reps * ex.weight
          });
        }
      });
    });

  if (!points.length) {
    progContent.innerHTML = `<p style="color:#888;">Keine Daten für „${esc(exerciseName)}" gefunden.</p>`;
    return;
  }

  const maxWeight = Math.max(...points.map(p => p.weight));
  const maxVol = Math.max(...points.map(p => p.volume));
  const first = points[0];
  const last = points[points.length - 1];
  const diffW = Math.round((last.weight - first.weight) * 100) / 100;
  const trend = points.length < 2
    ? ""
    : `<p style="margin:0 0 14px;color:#124381;">Entwicklung seit ${first.date.split("-").reverse().join(".")}: Gewicht <strong style="color:${diffW >= 0 ? "#119c32" : "#cf2014"}">${diffW >= 0 ? "+" : ""}${diffW} kg</strong>, Wiederholungen ${first.reps} → ${last.reps}</p>`;

  progContent.innerHTML = `
    <div class="chart-wrap">
      <h4>📊 ${esc(exerciseName)} – ${esc(c.first)} ${esc(c.last)}</h4>
      ${trend}
      ${buildChart(points)}
    </div>
    <table class="progress-table">
      <thead>
        <tr><th>Datum</th><th>Sätze</th><th>Wdh.</th><th>Gewicht (kg)</th><th>Volumen (kg)</th></tr>
      </thead>
      <tbody>
        ${points.map(p => `
          <tr>
            <td>${p.date ? p.date.split("-").reverse().join(".") : "–"}</td>
            <td>${p.sets}</td>
            <td>${p.reps}</td>
            <td class="${p.weight === maxWeight ? "best" : ""}">${p.weight}</td>
            <td class="${p.volume === maxVol ? "best" : ""}">${p.volume}</td>
          </tr>`).join("")}
      </tbody>
    </table>
    <p style="font-size:0.88rem;color:#888;">
      Bestes Gewicht: <strong>${maxWeight} kg</strong> &nbsp;|&nbsp;
      Höchstes Volumen: <strong>${maxVol} kg</strong>
      (Volumen = Sätze × Wdh. × Gewicht)
    </p>`;
}

function buildChart(points) {
  if (points.length < 2) {
    return '<p style="color:#888;margin:0;">Für die Grafik werden mindestens 2 Einheiten benötigt.</p>';
  }
  const W = 560, H = 190, padL = 48, padR = 16, padT = 16, padB = 34;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;
  const ws = points.map(p => p.weight);
  const minW = Math.min(...ws);
  const maxW = Math.max(...ws);
  const range = maxW - minW || 1;
  const step = innerW / (points.length - 1);
  const xy = points.map((p, i) => ({
    x: padL + i * step,
    y: padT + innerH - ((p.weight - minW) / range) * innerH
  }));
  const line = xy.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const every = Math.ceil(points.length / 8);

  const dots = xy.map((p, i) => `
    <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="5" fill="#0293ce"><title>${points[i].weight} kg × ${points[i].reps} Wdh.</title></circle>
    <text x="${p.x.toFixed(1)}" y="${(p.y - 10).toFixed(1)}" font-size="10" text-anchor="middle" fill="#124381">${points[i].weight}</text>`).join("");

  const xl = xy.map((p, i) => {
    if (i % every !== 0 && i !== points.length - 1) return "";
    const d = points[i].date ? points[i].date.split("-").slice(1).reverse().join(".") : "";
    return `<text x="${p.x.toFixed(1)}" y="${H - 10}" font-size="10" text-anchor="middle" fill="#124381">${d}</text>`;
  }).join("");

  return `<svg viewBox="0 0 ${W} ${H}" class="chart-svg" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Gewichtsverlauf">
    <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${padT + innerH}" stroke="#0293ce40"/>
    <line x1="${padL}" y1="${padT + innerH}" x2="${W - padR}" y2="${padT + innerH}" stroke="#0293ce40"/>
    <text x="${padL - 6}" y="${padT + 4}" font-size="10" text-anchor="end" fill="#888">${maxW} kg</text>
    <text x="${padL - 6}" y="${padT + innerH + 3}" font-size="10" text-anchor="end" fill="#888">${minW} kg</text>
    <polyline points="${line}" fill="none" stroke="#0293ce" stroke-width="2.5" stroke-linejoin="round"/>
    ${dots}
    ${xl}
  </svg>`;
}

/* =========================================================
   TRAINER VERWALTEN (nur Administratoren)
   ========================================================= */
function renderTrainers() {
  const list = document.getElementById("trainer-list");
  list.innerHTML = "";
  const adminCount = state.data.trainers.filter(t => t.isAdmin).length;
  state.data.trainers.forEach(t => {
    const li = document.createElement("li");
    const canDelete = t.id !== state.currentTrainer.id && !(t.isAdmin && adminCount <= 1);
    li.innerHTML = `
      <span>
        ${esc(t.name)}
        <span class="trainer-badge${t.isAdmin ? " admin" : ""}">${t.isAdmin ? "Admin" : "Trainer"}</span>
        <small style="color:#888;margin-left:6px;">@${esc(t.username)}</small>
      </span>
      <span>
        <button class="icon-btn" data-edit="${t.id}" title="Bearbeiten">✏️</button>
        ${canDelete ? `<button class="icon-btn" data-del="${t.id}" title="Löschen" style="color:#c00;">🗑️</button>` : ""}
      </span>`;
    list.appendChild(li);
  });
  list.querySelectorAll("[data-edit]").forEach(b => {
    b.onclick = () => editTrainer(Number(b.dataset.edit));
  });
  list.querySelectorAll("[data-del]").forEach(b => {
    b.onclick = () => deleteTrainer(Number(b.dataset.del));
  });
}

document.getElementById("new-trainer-btn").onclick = () => {
  document.getElementById("trainer-form-title").textContent = "Neuer Trainer";
  document.getElementById("trainer-form").reset();
  document.getElementById("trainer-id").value = "";
  document.getElementById("trainer-form-wrapper").classList.remove("hidden");
};
document.getElementById("cancel-trainer-form").onclick = () => {
  document.getElementById("trainer-form-wrapper").classList.add("hidden");
};
document.getElementById("trainer-form").onsubmit = e => {
  e.preventDefault();
  const id = document.getElementById("trainer-id").value;
  const name = document.getElementById("trainer-name").value.trim();
  const username = document.getElementById("trainer-username").value.trim();
  const password = document.getElementById("trainer-password").value;
  const isAdmin = document.getElementById("trainer-is-admin").checked;
  if (!name || !username || !password) {
    alert("Bitte alle Felder ausfüllen.");
    return;
  }
  if (state.data.trainers.some(t => t.username === username && t.id !== Number(id))) {
    alert("Dieser Benutzername ist bereits vergeben.");
    return;
  }
  if (id) {
    const t = state.data.trainers.find(x => x.id === Number(id));
    const otherAdmins = state.data.trainers.filter(x => x.isAdmin && x.id !== t.id).length;
    if (t.isAdmin && !isAdmin && otherAdmins === 0) {
      alert("Es muss mindestens ein Administrator vorhanden sein.");
      return;
    }
    Object.assign(t, { name, username, password, isAdmin });
    if (state.currentTrainer && state.currentTrainer.id === t.id) {
      document.getElementById("header-trainer-name").textContent = t.name;
      document.querySelectorAll(".admin-only").forEach(el => el.classList.toggle("hidden", !t.isAdmin));
    }
  } else {
    state.data.trainers.push({ id: Date.now(), name, username, password, isAdmin });
  }
  save();
  document.getElementById("trainer-form-wrapper").classList.add("hidden");
  renderTrainers();
};

function editTrainer(tid) {
  const t = state.data.trainers.find(x => x.id === tid);
  if (!t) return;
  document.getElementById("trainer-form-title").textContent = "Trainer bearbeiten";
  document.getElementById("trainer-id").value = t.id;
  document.getElementById("trainer-name").value = t.name;
  document.getElementById("trainer-username").value = t.username;
  document.getElementById("trainer-password").value = t.password;
  document.getElementById("trainer-is-admin").checked = !!t.isAdmin;
  document.getElementById("trainer-form-wrapper").classList.remove("hidden");
}
function deleteTrainer(tid) {
  const t = state.data.trainers.find(x => x.id === tid);
  if (!t) return;
  if (!confirm(`Trainer "${t.name}" wirklich löschen?`)) return;
  state.data.trainers = state.data.trainers.filter(x => x.id !== tid);
  save();
  renderTrainers();
}

/* --------- GEBURTSTAG --------- */
const birthdayInfo = document.getElementById("birthday-info");
function updateBirthday() {
  const today = new Date();
  const todayMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const ty = today.getFullYear();
  const list = state.data.customers
    .filter(c => c.dob)
    .map(c => {
      const [y, m, d] = c.dob.split("-").map(Number);
      if (!y || !m || !d) return null;
      let next = new Date(ty, m - 1, d);
      if (next < todayMidnight) next = new Date(ty + 1, m - 1, d);
      const diff = Math.round((next - todayMidnight) / 86400000);
      return { c, next, diff, age: next.getFullYear() - y };
    })
    .filter(Boolean)
    .sort((a, b) => a.diff - b.diff);
  if (!list.length) {
    birthdayInfo.textContent = "Keine Geburtsdaten hinterlegt.";
    return;
  }
  const n = list[0];
  const dateStr = `${pad(n.next.getDate())}.${pad(n.next.getMonth() + 1)}.`;
  const name = `${n.c.first} ${n.c.last}`.trim();
  const inText = n.diff === 0 ? "heute" : `in ${n.diff} Tag${n.diff === 1 ? "" : "en"}`;
  birthdayInfo.textContent = `🎂 ${name} – ${dateStr} (${inText}), wird ${n.age}`;
}
